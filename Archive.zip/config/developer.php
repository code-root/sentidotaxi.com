<?php

return [
    'name' => 'Mostafa Elbagory',
    'link' => 'https://wa.me/201001995914',
];

