@extends('site.layouts.app')

@section('title', 'Home Page')

@include('site.layouts.content')

@section('content')
    <!-- محتوى الصفحة الرئيسية هنا -->
@endsection
