<div class="header-top-bar" @if(session('locale') == 'ar') style="direction: rtl;" @endif>
    <div class="container">
        <div class="header-top">
            <div class="header-top-left">
                <ul class="header-info">
                    <li><a href="tel:+011235641231"><i class="icon-phone"></i>Call:
                            {{ $basicFields['phone'] ?? 'Not Available' }}</a></li>
                    <li><a href="mailto:{{ $basicFields['email'] ?? 'Not Available' }}" target="_blank"><i
                                class="icon-envelope"></i>Email: {{ $basicFields['email'] ?? 'Not Available' }}</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
