<!DOCTYPE html>
<html class="no-js" lang="<?php echo e($locale); ?>">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e($basicFields['site_name'] ?? 'My Website'); ?> <?php echo e($locale); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo e(asset('public/storage/' . ($basicFields['logo'] ?? 'default-logo.png'))); ?>">
    <!-- CSS
 ============================================ -->
    <link rel="stylesheet" href="/assets/site/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/icomoon.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/remixicon.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/magnifypopup.min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/lightbox.min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/animation.min.css">
    <link rel="stylesheet" href="https://edublink.html.devsblink.com/assets/css/vendor/jqueru-ui-min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/swiper-bundle.min.css">
    <link rel="stylesheet" href="/assets/site/css/vendor/tipped.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <!-- Site Stylesheet -->
    <link rel="stylesheet" href="/assets/site/css/app.css">
</head>

<style>
    .whatsapp-float {
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:4rem;
	box-shadow: 2px 2px 3px #999;
  z-index:100;

    }
</style>


<?php echo $__env->make('site.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- JS
 ============================================ -->
<!-- Modernizer JS -->
<script src="assets/site/js/vendor/modernizr.min.js"></script>
<!-- Jquery Js -->
<script src="assets/site/js/vendor/jquery.min.js"></script>
<script src="https://edublink.html.devsblink.com/assets/js/vendor/bootstrap.min.js"></script>
<script src="assets/site/js/vendor/sal.min.js"></script>
<script src="assets/site/js/vendor/jquery.waypoints.js"></script>
<script src="https://edublink.html.devsblink.com/assets/js/vendor/backtotop.min.js"></script>
<script src="assets/site/js/vendor/magnifypopup.min.js"></script>
<script src="assets/site/js/vendor/jquery.countdown.min.js"></script>
<script src="assets/site/js/vendor/jQuery.rProgressbar.min.js"></script>
<script src="assets/site/js/vendor/easypie.js"></script>
<script src="assets/site/js/vendor/odometer.min.js"></script>
<script src="assets/site/js/vendor/isotop.min.js"></script>
<script src="assets/site/js/vendor/imageloaded.min.js"></script>
<script src="assets/site/js/vendor/lightbox.min.js"></script>
<script src="assets/site/js/vendor/paralax.min.js"></script>
<script src="assets/site/js/vendor/paralax-scroll.min.js"></script>
<script src="assets/site/js/vendor/jquery-ui.min.js"></script>
<script src="assets/site/js/vendor/swiper-bundle.min.js"></script>
<script src="assets/site/js/vendor/svg-inject.min.js"></script>
<script src="assets/site/js/vendor/vivus.min.js"></script>
<script src="assets/site/js/vendor/tipped.min.js"></script>
<script src="assets/site/js/vendor/smooth-scroll.min.js"></script>
<script src="assets/site/js/vendor/isInViewport.jquery.min.js"></script>
<!-- Site Scripts -->
<script src="assets/site/js/app.js"></script>


<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/layouts/app.blade.php ENDPATH**/ ?>