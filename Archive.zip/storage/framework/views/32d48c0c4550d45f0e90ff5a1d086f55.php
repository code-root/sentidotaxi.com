<div class="hero-banner hero-style-12 bg-image photography-banner">
    <div class="swiper photography-activator">
        <div class="swiper-wrapper">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <img width="360px" height="360px" data-transform-origin='center center'
                        data-src="<?php echo e(asset('public/storage/' . $slider->image)); ?>" class="swiper-lazy" alt="image">
                    <div class="thumbnail-bg-content">
                        <div class="container cd-root-animated-shape">
                            <div class="row">
                                <div class="col-7">
                                    <div class="banner-content">
                                        <span class="subtitle" data-sal="slide-up"
                                            data-sal-duration="1000"><?php echo e($locale === 'ar' ? $slider->name_ar : $slider->name_en); ?></span>
                                        <h1 class="title" data-sal-delay="100" data-sal="slide-up"
                                            data-sal-duration="1000">
                                            <?php echo e($locale === 'ar' ? $slider->name_ar : $slider->name_en); ?></h1>
                                        <p data-sal-delay="200" data-sal="slide-up" data-sal-duration="1000">
                                            <?php echo e($slider->details); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="swiper-slide-controls slide-prev">
            <i class="icon-west"></i>
        </div>
        <div class="swiper-slide-controls slide-next">
            <i class="icon-east"></i>
        </div>

        <div class="pagination-box-wrapper">
            <div class="pagination-box-wrap">
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/partials/home-page/sliders.blade.php ENDPATH**/ ?>