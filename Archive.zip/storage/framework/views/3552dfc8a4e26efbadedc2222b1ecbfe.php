<?php $__env->startSection('title'); ?>
    <?php echo e('Home'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    
    <li class="breadcrumb-item active">Dashboard</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <!-- Content wrapper -->
    <div class="content-wrapper">
      <div class="container-xxl flex-grow-1 container-p-y">
        <div class="container">
            <h2>قائمة المشتركين</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>البريد الإلكتروني</th>
                        <th>تاريخ الاشتراك</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($subscriber->email); ?></td>
                            <td><?php echo e($subscriber->created_at->format('Y-m-d H:i:s')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
     
                </div>
    
          <?php $__env->stopSection(); ?>
          <?php $__env->startSection('footer-script'); ?>
  
  
  
          <?php $__env->stopSection(); ?>

  
<?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/dashboard/home.blade.php ENDPATH**/ ?>