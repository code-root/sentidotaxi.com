<div class="eman-team-area team-area-8 gap-tb-text"
    style="<?php echo e($locale === 'ar' ? 'direction: rtl;' : 'direction: ltr;'); ?>">
    <div class="container">
        <div class="section-title section-center" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
            <span class="pre-title color-secondary"><?php echo e($locale === 'ar' ? 'الشركاء' : 'Partners'); ?></span>
            <h2 class="title"><?php echo e($locale === 'ar' ? 'شركاؤنا في النجاح' : 'Our Success Partners'); ?></h2>
            <span class="shape-line"><i class="icon-19"></i></span>
        </div>
        <div class="row g-5">
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Start Partner Grid  -->
                <div class="col-lg-4 col-sm-6 col-12" data-sal-delay="50" data-sal="slide-up" data-sal-duration="800">
                    <div class="eman-team-grid team-style-1 team-style-8">
                        <div class="inner">
                            <div class="thumbnail-wrap">
                                <div class="thumbnail">
                                    <img src="<?php echo e(route('api.image.partners')); ?>?id=<?php echo e($partner->id); ?>"
                                        alt="<?php echo e($partner->name); ?>">
                                </div>
                            </div>
                            <div class="content">
                                <h5 class="title"><?php echo e($partner->{'name_' . $locale}); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Partner Grid  -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/partials/home-page/partners.blade.php ENDPATH**/ ?>