<?php $__env->startSection('title', 'Home Page'); ?>

<?php echo $__env->make('site.layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <!-- محتوى الصفحة الرئيسية هنا -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/home.blade.php ENDPATH**/ ?>