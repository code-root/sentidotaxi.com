<style>
    .cd-root-gallery-area {
        margin: 20px; /* هامش حول الـ div الكبيرة */
    }
    .thumbnail img {
        width: 45rem;
    height: 45rem;
    object-fit: cover;
    }
    .gallery-info {
        padding: 0px;
        text-align: center;
    }
    .gallery-info h3 {
        font-size: 1.5rem;
        margin: 0;
    }
    .gallery-info p {
        font-size: 1rem;
        color: #666;
    }
</style>
<div class="cd-root-gallery-area cd-root-section-gap">
    <div class="container">
        <div class="isotope-wrapper">
            <div class="isotop-button button-transparent isotop-filter">
                <button data-filter="*" class="is-checked">
                    <span class="filter-text">All</span>
                </button>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button data-filter=".<?php echo e($category->name_en); ?>">
                    <span class="filter-text"><?php echo e($category->name_en); ?></span>
                </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
            </div>
            <div class="isotope-list gallery-grid-wrap">
                <div id="animated-thumbnials">

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $category->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/public/storage/<?php echo e($gallery->image); ?>" class="cd-root-popup-image cd-root-gallery-grid p-gallery-grid-wrap isotope-item <?php echo e($category->name_en); ?>">
                        <div class="thumbnail">
                            <img src="/public/storage/<?php echo e($gallery->image); ?>" alt="<?php echo e($category->name_en); ?>">
                        </div>
                        <div class="gallery-info">
                            <h3><?php echo e($gallery->title ?? 'wfewfewf erfrfqref erfewfwef ewdewds'); ?></h3>
                            <p><?php echo e($gallery->description ?? 'fwefewfewf wef ewf ew fewfewf ew fewfwef'); ?></p>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/partials/home-page/gallery.blade.php ENDPATH**/ ?>