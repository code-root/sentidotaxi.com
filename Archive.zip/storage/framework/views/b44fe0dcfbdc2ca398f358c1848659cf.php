<div class="header-top-bar" style="<?php echo e($locale === 'ar' ? 'direction: rtl;' : 'direction: ltr;'); ?>">
    <div class="container">
        <div class="header-top">
            <div class="header-top-left">
                <ul class="header-info">
                    <li><a href="tel:+011235641231"><i class="icon-phone"></i>Call:
                            <?php echo e($basicFields['phone'] ?? 'Not Available'); ?></a></li>
                    <li><a href="mailto:<?php echo e($basicFields['email'] ?? 'Not Available'); ?>" target="_blank"><i
                                class="icon-envelope"></i>Email: <?php echo e($basicFields['email'] ?? 'Not Available'); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/partials/home-page/top-bar.blade.php ENDPATH**/ ?>