<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="shortcut icon" href="https://img.icons8.com/external-vitaliy-gorbachev-flat-vitaly-gorbachev/58/external-atoms-university-vitaliy-gorbachev-flat-vitaly-gorbachev.png">
    <title><?php echo e(config('app.name')); ?> Login</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100;200;300;400;500;600;700;800;900&amp;family=Nunito+Sans:ital,opsz,wght@0,6..12,200;0,6..12,300;0,6..12,400;0,6..12,500;0,6..12,600;0,6..12,700;0,6..12,800;0,6..12,900;0,6..12,1000;1,6..12,200;1,6..12,300;1,6..12,400;1,6..12,500;1,6..12,600;1,6..12,700;1,6..12,800;1,6..12,900;1,6..12,1000&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/vendors/icofont.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/vendors/themify.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/vendors/flag-icon.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/vendors/feather-icon.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/vendors/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/style.css">
    <link id="color" rel="stylesheet" href="https://admin.pixelstrap.com/cion/assets/css/color-1.css" media="screen">
    <link rel="stylesheet" type="text/css" href="https://admin.pixelstrap.com/cion/assets/css/responsive.css">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.cd-root.com/storage/app/public/logos/A2ghZzHNOun6FZCdste1w1PpqovvijpCI3dFVVRi.png">
</head>
  <body>
        <!-- login page start-->
        <div class="container-fluid p-0">
            <div class="row m-0">
              <div class="col-12 p-0">
                <div class="login-card login-dark" style="background-image: url('https://cutewallpaper.org/21/cryptocurrency-wallpaper-hd/Why-is-Malwarebytes-blocking-Coinhive-Malwarebytes-Labs-.jpg');">
                  <div>
                    <div>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

                    </div>
                    <div class="login-main">
                        <form class="theme-form" method="POST" action="<?php echo e(route('login.custom')); ?>">
                        <?php echo csrf_field(); ?>
                        <h3>Sign in to account</h3>
                        <p>Enter your email & password to login</p>
                        <a class="logo" href=""><img class="img-fluid for-light" src="<?php echo e(asset('storage' . ($settings['logo'] ?? 'default-logo.png'))); ?>" alt="looginpage" width="60%"><img class="img-fluid for-dark" src="/logo.png"  width="10%" alt="looginpage"></a>

                        <div class="form-group">
                            <label for="emailaddress">Email address</label>
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <a href="pages-recoverpw.html" class="text-muted float-right"><small>Forgot your password?</small></a>
                            <label for="password">Password</label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group mb-3">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>  class="custom-control-input">
                                <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                            </div>
                        </div>

                        <div class="form-group mb-0">
                          <div class="text-end mt-3">
                            <button class="btn btn-primary btn-block w-100" type="submit">Sign in</button>
                          </div>
                        </div>
                        <br>
         
                      </form>
                    </div>
                  </div>
                </div>
              </div>

            </div>
        </div>
        <footer class="footer footer-alt">
            <p class="text-muted">The final version issuance No. 3.1 Developer By <a href="<?php echo e(config('developer.link')); ?>"><?php echo e(config('developer.name')); ?></a></p>
            <script>document.write(new Date().getFullYear())</script>
        </footer>

</body><?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/dashboard/auth/login.blade.php ENDPATH**/ ?>