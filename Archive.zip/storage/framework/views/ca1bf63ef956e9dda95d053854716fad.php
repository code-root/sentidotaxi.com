<?php $__env->startSection('title', $page->{'name_' . app()->getLocale()}); ?>
<?php $__env->startSection('content'); ?>
    <div class="eman-breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-inner">
                <div class="page-title">
                    <h1 class="title"><?php echo e($page->{'name_' . app()->getLocale()}); ?></h1>
                </div>
                <ul class="eman-breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="separator"><i class="icon-angle-right"></i></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->{'name_' . app()->getLocale()}); ?></li>
                </ul>
            </div>
        </div>
        <ul class="shape-group">
            <li class="shape-1"><span></span></li>
            <li class="shape-2 scene"></li>
            <li class="shape-3 scene"></li>
            <li class="shape-4"><span></span></li>
            <li class="shape-5 scene"></li>
        </ul>
    </div>
    <section class="section-gap-equal contact-me-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9">
                    <div class="contact-me">
                        <div class="inner">
                            <div class="contact-us-info">
                                <h3 class="heading-title"><?php echo $page->{'name' . app()->getLocale()}; ?></h3>
                                <p><?php echo $page->{'description_' . app()->getLocale()}; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/pages/index.blade.php ENDPATH**/ ?>