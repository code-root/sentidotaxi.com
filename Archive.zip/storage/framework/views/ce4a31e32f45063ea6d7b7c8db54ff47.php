

<?php $__env->startSection('title', 'Content Page'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('site.partials.home-page.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('site.partials.home-page.about-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.partials.home-page.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.partials.home-page.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.partials.home-page.partners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php /**PATH /Users/macstoreegypt/Documents/Projects/adguid.ae/resources/views/site/layouts/content.blade.php ENDPATH**/ ?>